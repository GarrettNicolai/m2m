#define _STLP_PLATFORM "Mac"

#define _STLP_MAC  1

#error Looks like unsupported platform
#define _STLP_USE_UNIX_EMULATION_IO
